#pragma once
#include "inc.h"
#include "lmain.h"
	    
	    
void *CreateThread(void *ARG);
