#pragma once
#include "inc.h"

void maskcos(int nsam, float *outd, float ri2, float ri3, 
					float rih, float halfw, float amagp, float scal);
