#pragma once
#include "inc.h"

double cc3m(int nsam, int irad, float amag, CPLX *outc, 
	CPLX *outq, CPLX *c3df, CPLX *c3ds, int maxr1, int maxr2, 
	float phi, float theta, float psi, float shx, float shy, 
	//int ibuf, CPLX *pbuc, CPLX *pbuq,   //unused, removed by Xueming
	float rbfact, float *sinclut, 
	int ipad, float *rbuf, float *fsct, int iewald, float thetatr, 
	CPLX *ctff, CPLX *ctfs, float ri2, float ri3, float rih, float halfw);
