#pragma once
#include "inc.h"

extern "C" void a3d3_(int *nset, int *iswitch, int *nsam, 
	int *irad, float *ri, float *rrec, float *amagp, CPLX *datc, 
	CPLX *datq, CPLX *ctff, CPLX *ctfs, float *asum, float *vsum, 
	float *psum, CPLX *c3df, int *ksum, float *phi, float *theta, 
	float *psi, float *dshx, float *dshy, float *presa, float *pbc, float *   //int * pbc -- data type wrong
	boff, CPLX *a3df, CPLX *a3ds, float *s3df, float *s3ds, 
	double *std, CPLX *d3df, CPLX *d3ds, float *v3df, float *v3ds,
	 double *vtd, int *nn1, int *maxset, float *sinclut, 
	int *irada, int *ipad, float *thetatr, int *iewald, 
	CPLX *c3ds, float *sumprel, int *nprel, int *nsym, int *
	isym, int *jsym, float *symop, int *nnstat, long *nksum, 
	int *ifsc, int *imp);
