#pragma once
#include "inc.h"


void pinsert_s(int nsam, int irad, float rii, 
		int irrec2, CPLX *spec, CPLX *speq, CPLX *ctff, CPLX *ctfs, 
		CPLX *b3df, CPLX *b3ds, float *t3df, float *t3ds, 
		double *ttd, float shx, float shy, float *asum, float *vsum, 
		float *psum, CPLX *c3df, int *ksum, int isign, float *sinclut, 
		int irada, int ipad, float thet, int iewald, CPLX *c3ds, 
		float *sumprel, int *nprel, int nnstat, long *nksum, 
		int jc, float *dm, float tmp, int nsamh, int ic, 
		int irad2, float st, int i, cuMem *GM);
