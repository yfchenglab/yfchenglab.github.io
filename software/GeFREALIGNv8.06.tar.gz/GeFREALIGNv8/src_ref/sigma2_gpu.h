#pragma once
#include "inc.h"

void sigma2(float *psig2, int *pnsam, int *pirad, float *pamag, 
			CPLX *a3df, CPLX *a3ds,
			CPLX *datc, CPLX *datq, float *pphi, float *ptheta, float *ppsi, float *pshx,
			float *pshy, float *sinclut, int *pipad, int *piewald, float *pthetatr,
			CPLX *ctff, CPLX *ctfs, float *rbuf);
