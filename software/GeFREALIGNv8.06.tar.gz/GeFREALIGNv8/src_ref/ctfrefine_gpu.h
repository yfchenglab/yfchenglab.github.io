#include "inc.h"


int ctfrefine(float *dfmid1, float *dfmid2, float* angast, 
	int ifirstf, int lastf, bool fastig, int np, 
	int nsam, int maxr1, int maxr2, int *mask, int nn1, 
	float &ddfmid1, float &ddfmid2, float &dangast, CPLX  *c3df, 
	CPLX  *c3ds, int irad, CPLX  *outq, int npb, float *pbuf,
	CPLX  *pbuq, float *shx, float *shy, int ipad, float cs, float wl, 
	float wgh1, float wgh2, float thetatr, CPLX  *ctff, CPLX  *ctfs, 
	float *amag, float rih, float halfw, float ri2, float ri3, float ri4, 
	float *phi, float *theta, float *psi, float rmax1, float rmax2, 
	float xstd, float *mbuf, int *ilst, CPLX  *datc, CPLX  *datq, 
	int ibuf, float *b3dv, float *datd, float *sinclut, int ivflag,
	float rbfact, float *outd, CPLX  *outc, CPLX  *qbuc, CPLX  *qbuq, 
	bool ci, float *rbuf, float *fsct, int *film, int ilast, 
	int iewald, float tx, float ty);
