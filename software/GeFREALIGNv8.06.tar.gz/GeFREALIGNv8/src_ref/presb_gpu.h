#pragma once
#include "inc.h"

void presb(int nsam, int irad, float amag, CPLX *spec, 
	CPLX *speq, CPLX *c3df, CPLX *c3ds, 
	float phi, float theta, float psi, float shx, float shy, 
	float *rbin,float *sinclut, int ipad, float* rbuf, float thet , int iewald,
	CPLX *ctff, CPLX *ctfs, float ri2, float ri3, float rih, float halfw);
