#pragma once
#include "inc.h"

double cc3(int nsam, int irad, float amag, CPLX *spec, 
	CPLX *speq, CPLX *a3df, CPLX *a3ds, int maxr1, int maxr2, 
	float phi, float theta, float psi, float shx, float shy, 
	int ibuf, CPLX *pbuc, CPLX *pbuq, float rbfact, float *sinclut, 
	int ipad, float *rbuf, float *fsct, int iewald, float thetatr, 
	CPLX *ctff, CPLX *ctfs, float ri2, float ri3, float rih, float halfw);
