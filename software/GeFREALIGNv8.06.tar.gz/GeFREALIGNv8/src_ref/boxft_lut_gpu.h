#pragma once
#include "inc.h"

float boxft_lut(float *arg, float *sinclut);
