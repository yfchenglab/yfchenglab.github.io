#include "pthread.h"
#include "inc.h"



extern "C" void lock_();
extern "C" void unlock_();
