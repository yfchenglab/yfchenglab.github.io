#pragma once
#include "inc.h"

void cuda_pextract(int nsam, int irad, CPLX *outc, CPLX *outq,
					CPLX * a3df, CPLX *a3ds, float phi, float theta, float psi,
					float *sinclut, int ipad, float thet, int iewald, 
					CPLX *ctff, CPLX *ctfs);
