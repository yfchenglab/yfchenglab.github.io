#pragma once
#include "inc.h"


void maskenv(int nsam, float ri, float *outd, float *b3dv,
				float shx, float shy, float phi,float theta, float psi, float *w,
				int ibuf, cuMem *pGM);
