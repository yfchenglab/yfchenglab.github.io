#include "inc.h"

void ctfapply_phase_only(int nsam, CPLX *spec, CPLX *speq, 
	float shx, float shy, float cs, float wl, float wgh1, float wgh2, 
	float dfmid1, float dfmid2, float angast, float thetatr, CPLX *ctff, 
	CPLX *ctfs, float *outd, CPLX *outc, CPLX *outq, float amagp, 
	float rih, float halfw, float ri2, float ri3, float ri4, 
	float *datd, CPLX *datc, CPLX *datq, float *b3dv, float phi, 
	float theta, float psi, float *w, float xstd, int ibuf, 
	float tx, float ty);
