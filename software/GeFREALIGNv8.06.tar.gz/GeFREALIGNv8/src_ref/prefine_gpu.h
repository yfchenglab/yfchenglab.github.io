#pragma once
#include "inc.h"

void prefine(int nsam, int irad, float amag, 
		int maxr1, int maxr2, float &phi, float &theta, float &psi, 
		float &dshx, float &dshy, float &presa, int *mask, float &rbfact, 
		int &npar, int nn1, CPLX *c3df, CPLX *c3ds, CPLX *
		outq, int &npb, float *pbuf, CPLX *pbuq, float &shx, float &shy, 
		int &ipad, float cs, float wl, float &wgh1, float &wgh2, float &
		thetatr, CPLX *ctff, CPLX *ctfs, float &amagp, float &rih, float &
		halfw, float &ri2, float &ri3, float &ri4, float &rmax1, float &rmax2, 
		float &xstd, float *mbuf, int *ilst, CPLX *datc, CPLX *datq, 
		int ibuf, float *b3dv, float *datd, float *sinclut, int &ivflag,
	 	float *outd, CPLX *outc, CPLX *qbuc, CPLX *qbuq, float *rbuf, 
		float *fsct, int iewald, float &xm, float &ym, float &sx, float &sy, 
		float &sig2);
		

