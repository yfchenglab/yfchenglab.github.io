#pragma once

#include <complex>
#include <iostream>
#include <vector>
#include <list>
#include <string>
#include "stdlib.h"
#include "string.h"
#include "stdio.h"
#include "cuda.h"
#include "sys/time.h"
#include "cuMem.h"


//functions
#include "rlft3.h"
using namespace std;

#define CalTime(begin,end) ((end.tv_sec-begin.tv_sec)*1000000+end.tv_usec-begin.tv_usec)

typedef int logical;
typedef float2 CPLX;


static float PI=3.1415926535897;

extern "C"
{

	
	void rlft3o_(CPLX *data, CPLX *speq, int *nn1, int *nn2, int *nn3, int *isign);
	
	void iclose_(int* ifile);
	
	void date_and_time__(char *cdate, char *ctime, char *czone, int *dtval);

}

//Functions added by Xueming 
extern "C"
{
	void strtofile_(int* fileid, char* str, int* strlen);  //added into iof.f 
	void fflush_(int* fileid);  //added into iof.f
}


void safecall(cudaError_t call, const char* fname);
void checkerror(const char *fname);
void datatofile(void *data, size_t sizeinbyte, char *filename);

