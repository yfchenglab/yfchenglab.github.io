#pragma once
#include "cuda.h"
#include "pagelockedmem.h"


class cuMem
{
 public:
	//temp matrix, only read
	float *d_spec; // save one particle image 
	float *d_speq; 
	
	float *d_datc; // save one particle image 
	float *d_datq;
	
	float *d_outc; // save one particle image 
	float *d_outq;
	
	float *d_ctff;  // save ctf of one particle
	float *d_ctfs;
	cudaArray *cu_ctff;
	
	//temp matrix, for cc in psearch
	float *d_ccc;
	float *d_ccs;
	float *d_ccbuf;
	
	//temp matrix for 2D fft
	float *d_fft2d;
	float *d_fft2dt;
	int m_fft2dsize;
	
	//temp for mbuf, now only used in maskenv of ctfapply 
	float *d_mbuf;
	//temp used in pextract
	float *d_bf;
	
	//temp 
	float *d_sinclut;
	float *d_dm;
	float *d_wtf; //used in forward FFT
	float *d_wtb; //used in backward FFT
	float *d_wtf4; //used in forward FFT
	float *d_wtb4; //used in backward FFT
	float *d_wtfh; //used in forward FFT
	float *d_wtbh; //used in backward FFT
		
	//temp in sigma2
	float *d_mccpart;
	float *d_msum1;
	float *d_msum2;
	int *d_misum;

	//computing matrix
	float *d_a3df;  //3D reconstructuion 1
	float *d_a3ds;
	float *d_s3df;  //stat 1
	float *d_s3ds;
	
	float *d_d3df;  //3D reconstructuion 1
	float *d_d3ds;
	float *d_v3df;  //stat 1
	float *d_v3ds;
	
	float *d_c3df;  //reference volum
	float *d_c3ds;
	cudaArray *cu_c3df;
	cudaArray *cu_c3ds;
	
	float *d_sumprel;
	int *d_nprel;
	
	float *d_asum;
	float *d_vsum;
	float *d_psum;
	int *d_ksum;
	
	double *d_std;
	double *d_vtd;
	long *d_nksum;
	
	double *d_vn;
	double *d_vvn;
	double *d_vsn;
	double *d_vvsn;
	int *d_ic;
	
	//constant block size
	int rc_x;
	int rc_y;
public:
	int m_nrec;
public:
	
	int m_nsam;
	int m_nsamr;
	int m_ipad;
	int m_impmax;
	int m_nnstat;
	float *m_sinclut;
	float *m_c3df;
	float *m_c3ds;
	//page-locked
	float *m_plb3dv;

	
public: 
	cuMem();
	~cuMem();
	
public:
	void initial();
	void setThreadBlock(int idx, int idy);
	void set(int nsam, int ipad, int impmax, int nnstat, float *sinclut, PageLockedMem *plm);
	int alloc(int nrec);
	int getRec(float *a3df, float *a3ds, float *s3df, float *s3ds,
				  float *d3df, float *d3ds, float *v3df, float *v3ds);
	int getStat(float *sumprel, int * nprel, 
					float *asum, float * vsum, float *psum, int *ksum,
					double &std, double &vtd, long &nksum,
					double *vn, double *vvn, double *vsn, double *vvsn, int *ic);
	int free();
};
