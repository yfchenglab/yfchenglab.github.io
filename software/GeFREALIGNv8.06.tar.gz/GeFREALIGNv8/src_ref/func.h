#pragma once
#include "inc.h"

__host__ CPLX conjg(CPLX f);

__host__ float cabs(CPLX f);

__host__ CPLX cXc(CPLX a, CPLX b); // a*b

__host__ CPLX cDc(CPLX a, CPLX b); // a/b

__host__ CPLX cXr(CPLX a, float b);

__host__ CPLX cPc(CPLX a, CPLX b); //a+b

__host__ CPLX cMc(CPLX a, CPLX b);  //a-b


void outputpar(int njob, char *sline);

