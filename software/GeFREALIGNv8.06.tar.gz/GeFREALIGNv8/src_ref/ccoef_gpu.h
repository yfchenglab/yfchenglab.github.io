#pragma once
#include "inc.h"

float ccoef(int nsam, int irad, float amag, CPLX *a3df, 
	CPLX *a3ds, CPLX *datc, CPLX *datq, float phi, float theta, 
	float psi, float shx, float shy, float *sinclut, int ipad, 
	int iewald, float thetatr, CPLX *ctff, CPLX *ctfs, float *rbuf);
