#pragma once
#include "inc.h"

void pad(int nsam, int ipad, float *data, CPLX *speq, float *outd, CPLX *outq);
