#pragma once
#include "inc.h"

void va04a(float *x, float *e, int &n, float &f, float &escale, 
	int iprint, int icon, int &maxit, float *xpar, 
	int &npar, int nsam, int &maxr1, int &maxr2, int *mask, 
	int nn1, CPLX *c3df, CPLX *c3ds, int &irad, 
	CPLX *outq, int npb, float *pbuf, CPLX *pbuq, float *shx, 
	float *shy, int ipad, float cs, float wl, float &wgh1, float &wgh2, 
	float &thetatr, CPLX *ctff, CPLX *ctfs, float *amag, float &rih, 
	float halfw, float &ri2, float &ri3, float &ri4, float *phi, float *theta, 
	float *psi, float &rmax1, float &rmax2, float &xstd, float *mbuf, 
	int *ilst, CPLX *datc, CPLX *datq, int &ibuf, float *b3dv, float *datd, 
	float *sinclut, int &ivflag, float &rbfact, float *outd, 
	CPLX *outc, CPLX *qbuc, CPLX *qbuq, float *rbuf, float *fsct, 
	float *dfmid1, float *dfmid2, float *angast, int &iewald, float tx, 
	float ty, float xm, float ym, float &sx, float &sy, float &sig2);
