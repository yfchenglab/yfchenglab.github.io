#pragma once

#include <cuda.h>
#include "cufft.h"
#include <iostream>
#include <vector>
#include "stdlib.h"
#include "sys/time.h"
#include <pthread.h>
using namespace std;

typedef struct
{
	int N1; //in C order
	int N2;
	int N3;
	int isign;
	pthread_t tid;
	cufftHandle plan;
} planFFT;

typedef float2 CPLX;

extern "C" void rlft3_(CPLX *data, CPLX *speq, int *nn1, int *nn2, int *nn3, int *isign);

extern "C" void rlft3pl_(CPLX *data, CPLX *speq, int *nn1, int *nn2, int *nn3, int *isign);
void rlft3_GPU(CPLX *data, CPLX *speq, int nn1, int nn2, int nn3, int isign);
