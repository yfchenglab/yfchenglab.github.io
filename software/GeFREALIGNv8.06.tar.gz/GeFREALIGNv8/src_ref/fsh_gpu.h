#pragma once
#include "inc.h"

float fsh(float sig2, float x, float y, float xm, float ym, float sx, float sy);
