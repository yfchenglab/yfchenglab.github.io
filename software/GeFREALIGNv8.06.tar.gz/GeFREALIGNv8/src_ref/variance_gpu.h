#pragma once
#include "inc.h"

extern "C" void variance_(int *pnsam, CPLX *spec, CPLX *speq, float *pshx, float *pshy,
				float *pri, float *outd, CPLX *outc, CPLX *outq, 
				float *datd, CPLX *datc, CPLX *datq, int *ic, double *vsn, double *vn,
				double *vvsn, double *vvn, float *pamagp, float *buf, int *pna);
