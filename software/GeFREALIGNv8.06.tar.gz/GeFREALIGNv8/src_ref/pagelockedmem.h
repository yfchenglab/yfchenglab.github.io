#pragma once

class PageLockedMem
{
public:
	PageLockedMem();
	~PageLockedMem();
	
	float *pl_a3dv;
	float *pl_a3ds;
	float *pl_s3df;
	float *pl_s3ds;
	
	float *pl_d3dv;
	float *pl_d3ds;
	float *pl_v3df;
	float *pl_v3ds;
	
	float *pl_b3dv;
	float *pl_b3ds;
	float *pl_c3dv;
	float *pl_c3ds;
public:
	void free();	
};
