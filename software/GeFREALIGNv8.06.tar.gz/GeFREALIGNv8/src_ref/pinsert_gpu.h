#pragma once
#include "inc.h"

void pinsert(int &nsam, int &irad, float &ri, float &rrec, 
		float &amag, CPLX *spec, CPLX *speq, CPLX *ctff, 
		CPLX *ctfs, CPLX *a3df, CPLX *a3ds, float *s3df, float *s3ds, 
		CPLX *b3df, CPLX *b3ds, float *t3df, float *t3ds, double *ttd,
		 float &phi, float &theta, float &psi, float &shx, float &shy, float &presa,
		 float &pbc, float &boff, float *asum, float *vsum, float *psum, 
		 CPLX *c3df, int *ksum, int isign, float *sinclut, int &irada, 
		int &ipad, float thet, int &iewald, CPLX *c3ds, float *sumprel, 
		int *nprel, int &nsym, int *isym, int *jsym, 
		float *symop, int &nnstat, long *nksum, int &imp, cuMem *pGM);

