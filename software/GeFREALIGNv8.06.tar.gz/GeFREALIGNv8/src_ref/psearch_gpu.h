#pragma once
#include "inc.h"

void psearch(int nsam, int irad, float amag, 
	CPLX *spec, CPLX *speq, CPLX *a3df, CPLX *a3ds, int maxr1, int maxr2, 
	float &phi, float &theta, float &psi, float &dshx, float &dshy, //float &presa, 
	float *sang, int nsang, float *ccd, CPLX *ccc, CPLX *ccs, CPLX *cbuf, 
	int iquadmax, int *mask, float rbfact, float *sinclut, int ipad, 
	float *rbuf, float *fsct, int iewald, float thetatr, //CPLX *ctff, CPLX *ctfs, 
	float ri2, float ri3, float rih, float halfw, float *testpar, int	ipmax);
