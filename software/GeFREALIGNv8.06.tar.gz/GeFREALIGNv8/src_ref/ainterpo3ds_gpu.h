#pragma once
#include "inc.h"

CPLX ainterpo3ds(int nsam, int irad, CPLX *a3df, CPLX *a3ds, 
                float &xx, float &yy, float &zz,float *sinclut, int &ipad);
