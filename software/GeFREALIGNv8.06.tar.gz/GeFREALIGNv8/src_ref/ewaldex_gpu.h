#pragma once
#include "inc.h"


CPLX ewaldex(int &nsam, int &irad, CPLX *a3df, CPLX *a3ds, 
             float *sinclut, int &ipad,
             int &i, int &j,float *dm, float &thet, CPLX &ctfr, CPLX &ctfl);
