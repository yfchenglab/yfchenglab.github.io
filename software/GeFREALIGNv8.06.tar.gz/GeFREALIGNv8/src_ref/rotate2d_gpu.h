#pragma once
#include "inc.h"

void rotate2d(int nsam, int ipada, CPLX *spec, CPLX *speq, CPLX *outc, 
				float psi, CPLX *bufc);
