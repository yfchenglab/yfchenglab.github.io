#pragma once
#include "inc.h"

CPLX ainterpo3dbig(int nsama, int ipad, CPLX *a3df, CPLX *a3ds, 
                                      float &x, float &y, float &z);
