#pragma once
#include "inc.h"

void ctfapply(int *pnsam, CPLX *spec, CPLX *speq, 
	float *pshx, float *pshy, float *pcs, float *pwl, float *pwgh1, float *pwgh2, 
	float *pdfmid1, float *pdfmid2, float *pangast, float *pthetatr, CPLX *ctff, 
	CPLX *ctfs, float *outd, CPLX *outc, CPLX *outq, float *pamagp, 
	float *prih, float *phalfw, float *pri2, float *pri3, float *pri4, 
	float *datd, CPLX *datc, CPLX *datq, float *b3dv, float *pphi, 
	float *ptheta, float *ppsi, float *w, float *pxstd, int *pibuf, 
	float *ptx, float *pty);
