#pragma once
#include "inc.h"

__global__ void CTFAndPhaseShift(CPLX *spec, CPLX *speq, CPLX *datc, CPLX *datq,
					CPLX *outc, CPLX *outq, CPLX *ctff, CPLX *ctfs,int nsam, 
					int jc, int ic,float shx, float shy, float cs, float wl, 
					float wgh1, float wgh2, float dfmid1, float dfmid2,
					float angast, float thetatrp, float tx, float ty);
					
__global__ void CTFAndShift(CPLX *spec, CPLX *speq, CPLX *datc, CPLX *datq,
					CPLX *outc, CPLX *outq, CPLX *ctff, CPLX *ctfs,int nsam, 
					int jc, int ic,float shx, float shy, float cs, float wl, 
					float wgh1, float wgh2, float dfmid1, float dfmid2,
					float angast, float thetatrp, float tx, float ty);
					
__global__ void ShiftToOrigin(CPLX *datc, CPLX *datq, CPLX *outc, CPLX *outq, 
					int nsam, int jc, int nsamh);
