#pragma once
#include "inc.h"


void ccp(int nsam, int irad, float amag, CPLX *spec, CPLX *speq, 
	CPLX *a3df, CPLX *a3ds, float *rbuf,int maxr1, int maxr2, 
	float &phi, float &theta, float &psi, float &shx, float &shy, 
	float &ccmax, float *ccd, CPLX *ccc, CPLX *ccs, CPLX *cbuf, 
	int iquad, int *mask, float rbfact, float *sinclut, int ipad, 
	int iewald, float thetatr, /*CPLX *ctff, CPLX *ctfs,*/ 
	float ri2, float ri3, float rih, float halfw, int iquadmax);
