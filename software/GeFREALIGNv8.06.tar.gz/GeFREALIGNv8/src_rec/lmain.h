#pragma once
#include "inc.h"


void lmain_(int &k, logical &fdef, logical &fmag, int &inproj, char &cform, 
			float *data, float *rrec, int &nsam, CPLX *spec, float *shx, 
			float *shy, float *cs, float *rawbins, float *wl, float &wgh1, 
			float &wgh2, float *dfmid1, float *dfmid2, float *angast, CPLX *outc, 
			float *outd, float *amagp, float &rih, float &halfw, float &halfwc, 
			float &ri2, float &ri3, float &ri4, float *datd, CPLX *datc, 
			float *b3dv, float *phi, float *theta, float *psi, float &xstd, 
			int &iflag, int &irada, CPLX *c3df, CPLX *c3ds, float *rbins, 
			float *rbinn, int &nset, CPLX *noic, float *nois, float *presa, 
			float *sang, int &nsang, float *ccd, CPLX *ccc, int &iquadmax,
			
			int &ndoc1, int &ndoc2, int *mask, float *rbfac, float *rmax1, 
			float *rmax2, int &iran, float &psize, float *dstep, int *film, 
			int &nn1, int &nnpart, int &maxset, logical &fhist, int *ilist, 
			int &npb, int &itmax, float &damax, logical &asymstore, float *target, 
			int &iccount, int &iswitch, int &ipad, float &pall, int &iall, 
			int &irad, float &ri, CPLX *a3df, CPLX *a3ds, float *s3df, 
			float *s3ds, double &std, CPLX *d3df, CPLX *d3ds, int *ilst, 
			float *v3df, float *v3ds, double &vtd, float &pbc, float &boff, 
			logical &fflip, float *asum, float *vsum, float *psum, int *ksum, 
			float *thresh, int &nsamh,	int &jc, int &fflag, float &ccave,
			 			
			int &icmp, int &ifirst, int &ioproj, int &iewald, int &nscf, 
			char *sfile, int &nang, float &wgh, float &psis, float &thetas, 
			float &phis, float &dshxs, float &dshys, float &press, int &iexcl, 
			int &ibuf, int &icount, logical &fmatch, float &dfmid1s, float &dfmid2s, 
			float &angasts, float &absmags, int &nstart, char *finpat1, char *finpat2, 
			char *asym, char *vx, int &ilast, int *nnset, int &iang, 
			char *cdate, char *ctime, char *czone, int *dtval, logical &fastig, 
			float *sinclut, float *mbuf, float *pbuf, CPLX *ctff, CPLX *ctfs, 
			float *rbin, CPLX *ccbuf, CPLX *ccs, CPLX *datq, CPLX *outq, 
			CPLX *noiq, CPLX *speq, CPLX *pbuq, CPLX *qbuc, CPLX *qbuq, 
			
			int &istat, int *tnset, logical &fall, int *ic, double *vsn, 
			double *vn, double *vvsn, double *vvn, logical *cia, float *bf, 
			int *ns, int &na, float *fsct, float *sumprel, int *nprel, 
			float *tx, float *ty, float *testpar, int &ipmax, int &nsym, 
			int *isym, int *jsym, float *symop, int &nnstat, long &nksum, 
			float *xm, float *ym, float *sx, float *sy, int &ifsc, 
			int &imp, int &njob, int nGPU);
