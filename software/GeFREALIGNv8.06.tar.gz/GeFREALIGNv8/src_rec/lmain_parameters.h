#pragma once
#include "inc.h"

class lmain_parameters
{
public:
	lmain_parameters();
	~lmain_parameters();
	
public:
	int m_DeviceNum;  //the device number will be used

public:
	int m_kstart; 
	int m_kend;
	int m_IMPMAX;
	PageLockedMem *m_plm;
	int m_nthread;
	int m_nGPU;
	
	logical m_fdef; 
	logical m_fmag; 
	int m_inproj; 
	char m_cform; 
	float *m_data; 
	float *m_rrec; 
	int m_nsam; 
	CPLX *m_spec; 
	float *m_shx; 
	
	float *m_shy; 
	float *m_cs; 
	float *m_rawbins; 
	float *m_wl; 
	float m_wgh1; 
	float m_wgh2; 
	float *m_dfmid1; 
	float *m_dfmid2; 
	float *m_angast; 
	CPLX *m_outc;
	 
	float *m_outd; 
	float *m_amagp; 
	float m_rih; 
	float m_HALFW; 
	float m_halfwc; 
	float m_ri2; 
	float m_ri3; 
	float m_ri4; 
	float *m_datd; 
	CPLX *m_datc; 
	     
	float *m_b3dv; 
	float *m_phi; 
	float *m_theta; 
	float *m_psi; 
	float m_xstd; 
	int m_iflag; 
	int m_irada; 
	CPLX *m_c3df; 
	CPLX *m_c3ds; 
	float *m_rbins; 
	
	float *m_rbinn; 
	int m_nset; 
	CPLX *m_noic; 
	float *m_nois; 
	float *m_presa; 
	float *m_sang; 
	int m_nsang; 
	float *m_ccd; 
	CPLX *m_ccc; 
	int m_iquadmax; 
	
	int m_NDOC1; 
	int m_NDOC2; 
	int *m_mask; 
	float *m_rbfac; 
	float *m_rmax1; 
	float *m_rmax2; 
	int m_iran; 
	float m_psize; 
	float *m_dstep; 
	int *m_film; 
	
	int m_NN1; 
	int m_NNPART; 
	int m_MAXSET; 
	logical m_fhist; 
	int *m_ilist; 
	int m_NPB; 
	int m_itmax; 
	float m_DAMAX; 
	logical m_asymstore; 
	float *m_target; 
	
	int m_iccount; 
	int m_iswitch; 
	int m_ipad; 
	float m_pall; 
	int m_iall; 
	int m_irad; 
	float m_ri; 
	CPLX *m_a3df; 
	CPLX *m_a3ds; 
	float *m_s3df; 
	
	float *m_s3ds; 
	double m_std; 
	CPLX *m_d3df; 
	CPLX *m_d3ds; 
	int *m_ilst; 
	float *m_v3df; 
	float *m_v3ds; 
	double m_vtd; 
	float m_pbc; 
	float m_boff; 
	
	logical m_fflip; 
	float *m_asum; 
	float *m_vsum; 
	float *m_psum; 
	int *m_ksum; 
	float *m_thresh; 
	int m_nsamh; 
	int m_jc; 
	int m_fflag; 
	float m_ccave; 
	
	int m_icmp; 
	int m_ifirst; 
	int m_ioproj; 
	int m_iewald; 
	int m_NSCF; 
	char *m_sfile; 
	int m_nang; 
	float m_wgh; 
	float m_psis; 
	float m_thetas; 
	
	float m_phis; 
	float m_dshxs; 
	float m_dshys; 
	float m_press; 
	int m_iexcl; 
	int m_ibuf; 
	int m_icount; 
	logical m_fmatch; 
	float m_dfmid1s; 
	float m_dfmid2s; 
	
	float m_angasts; 
	float m_absmags; 
	int m_nstart; 
	char *m_finpat1; 
	char *m_finpat2; 
	char *m_asym; 
	char *m_vx; 
	int m_ilast; 
	int *m_nnset; 
	int m_IANG; 
	
	char *m_cdate; 
	char *m_ctime; 
	char *m_czone; 
	int *m_dtval; 
	logical m_fastig; 
	float *m_sinclut; 
	float *m_mbuf; 
	float *m_pbuf; 
	CPLX *m_ctff; 
	CPLX *m_ctfs; 
	
	float *m_rbin; 
	CPLX *m_ccbuf; 
	CPLX *m_ccs; 
	CPLX *m_datq; 
	CPLX *m_outq; 
	CPLX *m_noiq; 
	CPLX *m_speq; 
	CPLX *m_pbuq; 
	CPLX *m_qbuc; 
	CPLX *m_qbuq; 
	
	int m_istat; 
	int *m_tnset; 
	logical m_fall; 
	int *m_ic; 
	double *m_vsn; 
	double *m_vn; 
	double *m_vvsn; 
	double *m_vvn; 
	logical *m_ci; 
	float *m_bf; 
	
	int *m_ns; 
	int m_na; 
	float *m_fsct; 
	float *m_sumprel; 
	int *m_nprel; 
	float *m_tx; 
	float *m_ty; 
	float *m_testpar; 
	int m_ipmax; 
	int m_nsym; 
	
	int *m_isym; 
	int *m_jsym; 
	float *m_symop; 
	int m_NNSTAT; 
	long m_nksum; 
	float *m_xm; 
	float *m_ym; 
	float *m_sx; 
	float *m_sy; 
	int m_ifsc; 
	
	int m_imp; 
	int m_ISYMAX;

   int m_xBlockSize;
   int m_yBlockSize;
   int m_nrec;	
   int m_step;
private:
	bool m_setNew2DImage;
	
public:
	void initial();
	void setReconstructionNum(int n);
	void setDevice(int n);
	void setThreadNum(int n, int nGPU);
	void setStep(int n);
	void setBlockSize(int x, int y);
	void set(int kstart,int kend, PageLockedMem *plm, int IMPMAX,
			logical fedf, logical fmag, int inproj, char cform, float *data, 
			float *rrec, int nsam, CPLX *spec, float *shx, float *shy, float *cs, 
			float *rawbins, float *wl, float wgh1, float wgh2, float *dfmid1, float *dfmid2, 
			float *angast,	CPLX *outc,	float *outd, float *amagp, float rih, float HALFW, 
			float halfwc, float ri2,float ri3, float ri4,float *datd, CPLX *datc, float *b3dv, 
			float *phi, float *theta, float *psi, float xstd, int iflag, int irada, CPLX *c3df, 
			CPLX *c3ds, float *rbins, float *rbinn, int nset, CPLX *noic, float *nois, float *presa, 
			float *sang, int nsang, float *ccd, CPLX *ccc, int iquadmax, int NDOC1, int NDOC2, 
			int *mask, float *rbfac, float *rmax1, float *rmax2, int iran, float psize, 
			float *dstep, int *film, int NN1, int NNPART, int MAXSET, logical fhist, int *ilist, 
			int NPB, int itmax, float DAMAX, logical asymstore, float *target, int iccount, 
			int iswitch, int ipad, float pall, int iall, int irad, float ri, CPLX *a3df, 
			CPLX *a3ds, float *s3df, float *s3ds, double std, CPLX *d3df, CPLX *d3ds, int *ilst, 
			float *v3df, float *v3ds, double vtd, float pbc, float boff, logical fflip, 
			float *asum, float *vsum, float *psum, int *ksum, float *thresh, int nsamh, 
			int jc, int fflag, float ccave, int icmp, int ifirst, int ioproj, int iewald, 
			int NSCF, char *sfile, int nang, float wgh, float psis, float thetas, float phis, 
			float dshxs, float dshys, float press, int iexcl, int ibuf, int icount, 
			logical fmatch, float dfmid1s, float dfmid2s, float angasts, float absmags, 
			int nstart, char *finpat1, char *finpat2, char *asym, char *vx, int ilast, 
			int *nnset, int IANG, char *cdate, char *ctime, char *czone, int *dtval, 
			logical fastig, float *sinclut, float *mbuf, float *pbuf, CPLX *ctff, CPLX *ctfs, 
			float *rbin, CPLX *ccbuf, CPLX *ccs, CPLX *datq, CPLX *outq, CPLX *noiq, 
			CPLX *speq, CPLX *pbuq, CPLX *qbuc, CPLX *qbuq, int istat, int *tnset, logical fall, 
			int *ic, double *vsn, double *vn, double *vvsn, double *vvn, logical *ci, 
			float *bf, int *ns, int na, float *fsct, float *sumprel, int *nprel, float *tx, 
			float *ty, float *testpar, int ipmax, int nsym, int *isym, int *jsym, float *symop, 
			int NNSTAT, long nksum, float *xm, float *ym, float *sx, float *sy, int ifsc, 
			int imp, int ISYMAX);
	int set_iswitch(int iswitch); // return the old value
	int set_New2DImage(); // particle image(speq,spec) ,ctf(ctff, ctfs) and dm
	void free();
}; 
